interface MyInterface{
	public void m1();
	public void m2();
	public default void m3() {
		System.out.println("MyInterface m3  'Default' method ");
	}
}
class MyInterfaceImpl implements MyInterface{

	@Override
	public void m1() {
		System.out.println("MyInterfaceImpl - m1");
	}

	@Override
	public void m2() {
		System.out.println("MyInterfaceImpl - m1");		
	}
//	@Override
//	public void m3() {
//	System.out.println("MyinterfaceImpl - m3");
//	}
}
public class Lab1 {
	public static void main(String[] args) {
		MyInterface in1 = new MyInterfaceImpl();
		in1.m1();
		in1.m2();
		in1.m3();

	}
}
