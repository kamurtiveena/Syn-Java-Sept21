interface MyInt{
	public void m1();
	public void m2();
	public static void m3() {
		System.out.println("MyInterface static m3  method ");
	}
}
class MyIntImpl implements MyInt{

	@Override
	public void m1() {
		System.out.println("MyInterfaceImpl - m1");
		
	}

	@Override
	public void m2() {
		System.out.println("MyInterfaceImpl - m1");		
	}
}
public class Lab3 {
	public static void main(String[] args) {
		MyInt in1 = new MyIntImpl();
		in1.m1();
		in1.m2();
		
		MyInt.m3();
		//in1.m3();

	}
}
