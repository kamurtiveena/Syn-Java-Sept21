/*class Lab1Helper implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("run of Lab1Helper invoked");
	}
}*/
public class Lab1 {

	public static void main(String[] args) {
	//	Runnable r1 = new Lab1Helper();
		Runnable r1 =  () -> 	System.out.println("run of Lab1Helper invoked");
		Thread t1 = new Thread(r1);
		t1.start();
	}
}
