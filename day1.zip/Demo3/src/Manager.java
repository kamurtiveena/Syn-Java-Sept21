import java.util.List;
import java.util.function.Predicate;

public interface Manager <T>{
	default void insert (T obj) {
		getList().add(obj);
	}

	public default void delete(Predicate<T> pred) {
		getList().removeIf(pred);
	}
	
	List<T> getList();
	void update(T newobj);
}
